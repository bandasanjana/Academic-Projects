
# SQL-Data-Analysis
Sql queries using Aggregate, group by and having functions.
Sql queries using joins
Sql sub-queires including both independent and correleated -Created views
The File contains Excel- sheets of Data Representation: -The Data Analysis is made using Statistical and Econometric concepts in real-time situations.Impactful Data Representation is done using the correct charts for the respective data. observations of the charts are noted down in the insert box on each sheet.
